package constant;

public enum EDepartment {
    ACCOUNTANT,
    PERSONNEL,
    SALE,
}
