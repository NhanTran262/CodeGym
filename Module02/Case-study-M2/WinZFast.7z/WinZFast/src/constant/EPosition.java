package constant;

public enum EPosition {
    MANAGER,
    STAFF,
}
