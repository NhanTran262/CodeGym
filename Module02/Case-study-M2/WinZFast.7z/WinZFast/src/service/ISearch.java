package service;

import entity.Product;

import java.util.List;

public interface ISearch {
    void search(List<Product> products);
}
