package service;

public interface ISender {
public void send(String email);
}
