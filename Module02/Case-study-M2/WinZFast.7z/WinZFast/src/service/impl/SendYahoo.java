package service.impl;

import service.ISender;

public class SendYahoo implements ISender {
    @Override
    public void send(String email) {

    }
}
