create definer = root@localhost trigger tickets_event_times_fk
    before insert
    on tickets
    for each row
BEGIN
    DECLARE event_id_val BINARY(16);
    DECLARE time_id_val BINARY(16);

    -- Retrieve the event_id and time_id values from event_times table
    SELECT event_id, time_id
    INTO event_id_val, time_id_val
    FROM event_times
    WHERE event_id = NEW.event_id
      AND time_id = NEW.time_id;

    -- Check if the event_id and time_id values exist in the event_times table
    IF event_id_val IS NULL OR time_id_val IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid event_id or time_id';
    END IF;
END;

